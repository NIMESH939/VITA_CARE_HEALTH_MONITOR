<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="welcome-style.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <title>Welcome</title>

    <style>
      .header{
         position: fixed;
         top: 0;
         left: 0;
         width: 100%;
         padding: 16px 10%;
         background: transparent;
         display: flex;
         justify-content: space-between;
         align-items: center;
         z-index: 100;
         box-shadow: 0 5px 10px rgba(0,0,0,.1);
      }

      .logo{
         font-size: 25px;
         color: #002D62;
         text-decoration: none;
         font-weight: 600;
         
      }
      .logo:hover{
         color: #51ACC5;
      }
   </style>
   
</head>
<body>
    <header class="header">
        <a href='logout.php' class="logo">LOGOUT</a>
    </header>
    <div class="box">
        <div class="container">

            <div class="top">
                <header>WELCOME</header>
            </div>
            <?php
        // Establish database connection
        @include "config.php";
        session_start();
        // Retrieve username from the database
        $userId = $_SESSION['user_name'];
        /*$sql = "SELECT username FROM users WHERE username = '$userId'";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $user_name = $row['username'];
        }*/

        echo "<div class='username'>Welcome, " . $userId . "</div>";

        $conn->close();
        ?>
            <div class="input-field">
                <button class="submit" onclick="window.location.href='medicine form/index.php'">Medicine Schedule</button>
            </div>
            <div class="para">
                <p>Here you can get information about the time to take the medicine and the type of medicine that are
                    covered.</p>
            </div>

            <div class="input-field">
                <button class="submit" onclick="window.location.href='graphs/newwChamo.php'">Patient Details</button>
            </div>

            <div class="para">
                <p>Here you can get long-term information about the patient's condition.</p>
            </div>
        </div>
    </div>
</body>

</html>