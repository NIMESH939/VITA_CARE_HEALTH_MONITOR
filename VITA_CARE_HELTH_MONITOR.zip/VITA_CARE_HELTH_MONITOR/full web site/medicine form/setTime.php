<?php include 'connection.php';?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.1.1/css/bootstrap.min.css" /> 
    <style>
        .header{
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            padding: 16px 10%;
            background: transparent;
            display: flex;
            justify-content: space-between;
            align-items: center;
            z-index: 100;
            box-shadow: 0 5px 10px rgba(0,0,0,.1);
            
        }

        .logo{
            font-size: 25px;
            color: #25354e;
            text-decoration: none;
            font-weight: 700;
        }
    </style>
</head>
<body style="background: #1f75fe">
<header class="header">
        <a href="http://localhost/full%20web%20site/medicine form/index.php" class="logo">BACK</a>
</header>
<div class="container" style="padding-top: 90px">
        <div class="row my-4">
            <div class="col-lg-20 mx-auto">
                <div class="card shadow">
                    <div class="card-header">
                        <h4>Add Schedule</h4>
                    </div>
                    <div class="card-body p-10">
                        <form action="" method="POST" name="term_times" id="term_times">
                            <div id="show_item">
                                <div class="row">
                                    <div class="col-md-3 mb-3">
                                        <p>Morning</p>
                                    </div>
                                    <div class="col-md-3 mb-3">
                                        <input type="number" name="m_hour" id="m_hour"class="form-control" min="0" max="23" step="1"
                                        placeholder="Enter hour" required>
                                    </div>

                                    <div class="col-md-3 mb-3">
                                        <input type="number" name="m_minutes" id="m_minutes" class="form-control" min="1" max="59" step="1"
                                        placeholder= "Enter Minutes" required>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-3 mb-3">
                                        <p>Afternoon</p>
                                    </div>
                                    <div class="col-md-3 mb-3">
                                        <input type="number" name="a_hour" id="a_hour" class="form-control" min="0" max="23" step="1"
                                        placeholder="Enter hour" required>
                                    </div>

                                    <div class="col-md-3 mb-3">
                                        <input type="number" name="a_minutes" id="a_minutes" class="form-control" min="1" max="59" step="1"
                                        placeholder= "Enter Minutes" required>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-3 mb-3">
                                        <p>Evening</p>
                                    </div>
                                    <div class="col-md-3 mb-3">
                                        <input type="number" name="e_hour" id="e_hour" class="form-control" min="0" max="23" step="1"
                                        placeholder="Enter hour" required>
                                    </div>

                                    <div class="col-md-3 mb-3">
                                        <input type="number" name="e_minutes" id="e_minutes" class="form-control" min="1" max="59" step="1"
                                        placeholder= "Enter Minutes" required>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-3 mb-3">
                                        <p>Night</p>
                                    </div>
                                    <div class="col-md-3 mb-3">
                                        <input type="number" name="n_hour" id="n_hour" class="form-control" min="0" max="23" step="1"
                                        placeholder="Enter hour" required>
                                    </div>

                                    <div class="col-md-3 mb-3">
                                        <input type="number" name="n_minutes" id="n_minutes" class="form-control" min="1" max="59" step="1"
                                        placeholder= "Enter Minutes" required>
                                    </div>
                                </div>
                            </div>
                            <div>
                                <input type="submit" value="Submit" class="btn btn-primary w-25" id="add_btn">
                            </div>

                        </form> 
                    </div>
            </div>
        </div>
    </div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/firebase/7.14.1-0/firebase.js"></script>
<script src="setTime_js.js" type="module"></script>
</body>
</html>