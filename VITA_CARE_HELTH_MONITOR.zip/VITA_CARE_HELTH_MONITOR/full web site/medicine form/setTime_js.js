const firebaseConfig = {
  apiKey: "AIzaSyCdREkP5NR6P3PWxP-IL094Pqk1atycSaQ",
  authDomain: "hardware-project-6c299.firebaseapp.com",
  databaseURL: "https://hardware-project-6c299-default-rtdb.firebaseio.com",
  projectId: "hardware-project-6c299",
  storageBucket: "hardware-project-6c299.appspot.com",
  messagingSenderId: "703471520126",
  appId: "1:703471520126:web:294f24a86be6ddbf340b2f"
};

// initialize firebase
firebase.initializeApp(firebaseConfig);

// reference your database
var messagesRef2 = firebase.database().ref("Day_times");

document.getElementById('term_times').addEventListener('submit', submitForm2);

function submitForm2(e) {
  e.preventDefault();

  var m_hour = parseInt(document.getElementById("m_hour").value);
  var m_minutes = parseInt(document.getElementById("m_minutes").value);
  var a_hour = parseInt(document.getElementById("a_hour").value);
  var a_minutes = parseInt(document.getElementById("a_minutes").value);
  var e_hour = parseInt(document.getElementById("e_hour").value);
  var e_minutes = parseInt(document.getElementById("e_minutes").value);
  var n_hour = parseInt(document.getElementById("n_hour").value);
  var n_minutes = parseInt(document.getElementById("n_minutes").value);

  saveMessage(m_hour, m_minutes, a_hour, a_minutes, e_hour, e_minutes, n_hour, n_minutes);

  //form.reset();
}

//save message
/*const saveMessage = (item1, item2, item3, item4) => {
    var newMessageRef = messagesRef.push()
    newMessageRef.set({
        item1 : item1,
        item2 : item2,
        item3 : item3,
        item4 : item4,
    });
};*/

//update node
const saveMessage = (item1, item2, item3, item4, item5, item6, item7, item8) => {
  messagesRef2.update({
    //var newMessageRef = messagesRef2.push()
    //newMessageRef.set({
    m_hour: item1,
    m_minutes: item2,
    a_hour: item3,
    a_minutes: item4,
    e_hour: item5,
    e_minutes: item6,
    n_hour: item7,
    n_minutes: item8,
  });
};
